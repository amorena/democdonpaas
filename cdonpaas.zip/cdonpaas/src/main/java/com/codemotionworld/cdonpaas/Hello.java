package com.codemotionworld.cdonpaas;

public class Hello {

    public String say() {
        return "Hello World!";
    }
}
