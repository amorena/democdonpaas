package com.codemotionworld.cdonpaas;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/")
public class WelcomeServlet {

    @Produces("text/html")
    @GET
    public String welcome() {
        return "<html><head><title>Welcome</title></head><body><a href='/hello'>Welcome to Red Hat's PaaS - TECHLAB 2014 - Test My HelloWorld Service here</a></body></html>";
    }
}
